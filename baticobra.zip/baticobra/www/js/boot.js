bootGame = {

		create:function(){
				game.physics.startSystem(Phaser.Physics.ARCADE);
				game.world.setBounds(0,0,bounds,0);
				keyboard = game.input.keyboard.createCursorKeys();

                game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
                game.scale.forceLascape = true;
                game.scale.pageAlignHorizontally = true;
                game.scale.pageAlignVertically = true;
                game.state.start("preloadGame");
		},
        update: function () {
        game.scale.pageAlignVertically = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.setShowAll();
        game.scale.refresh();
    }

}
preloadGame = {
	preload:function(){
        game.load.spritesheet('player','img/player.png',233,251);
       
        game.load.spritesheet('tsato', 'img/tsato.png',50,50);
        game.load.spritesheet('ai', 'img/ai.png',233,202);
        game.load.spritesheet('ai2', 'img/ai.png',233,202);
        game.load.spritesheet("start","img/startbut.png",263,117);
        game.load.spritesheet("menu2","img/menu2.png",95,94);
        game.load.image('about2','img/about2.png');
		game.load.image('bg','img/sky.png');
		game.load.image('play','img/play.png');
		game.load.image('fire','img/fire.png');
		//game.load.image('platform','img/platform.png');
        game.load.image('gameover', 'img/gameover.png');
        game.load.image('line', 'img/line.png');
		game.load.image('ins','img/instruction.png');
        game.load.image('abawt','img/aboutbtn.png');
        game.load.image('intruc',"img/instruc.png");
        game.load.audio('pak', 'audio/tsato.mp3')
        game.load.spritesheet('pauseButton','img/pause.png',91,91);

   
	},

create:function(){

	    game.state.start("menuGame");
  }
}


menuGame = {
	create:function(){
		game.add.image(0,0, "play");

        pbtn = game.add.button(490,290,"start",this.lundag);
        pbtn.anchor.set(0.5);
		pbtn.scale.set(0.5);  

          tungkol = game.add.button(490,369,"abawt",this.tng);
                tungkol.anchor.set(0.5);

        la = game.add.button(490,442,"intruc",this.lala);
         la.anchor.set(0.5);
        la.scale.set(0.9);  
	},

lundag:function (){
        game.state.start("playGame");
   



   },

    tng: function(){
            about=game.add.image(0,0,"about2");
            about.scale.set(1.0);

            
            restartButton=game.add.button(20,0,"menu2",restartB,this);
            function restartB() {
            
            restartButton.destroy();

            
            game.state.start("menuGame");
            }

            },
    lala: function(){
            about=game.add.image(0,0,"ins");
            about.scale.set(1.0);


            restartButton=game.add.button(20,0,"menu2",restartB,this);
            function restartB() {
            restartButton.destroy();

            game.state.start("menuGame");
            }

            },

}
        
playGame = {
		create:function(){
        keyboard = game.input.keyboard.createCursorKeys();
        btnfire = game.add.button(0,0,'fire',tsatoGame.pushRight);
		game.add.image(0,0,'bg');
		

		line = game.add.sprite(550,540,'line');
    game.physics.arcade.enable(line);
    line.body.immovable=true;
    
		ai = game.add.sprite(100,50,'ai');
		
		player = game.add.sprite(700,300,'player');
		
		player.animations.add('player',[0,1,0,1,0,0],24,false);
		ai.animations.add('ai',[0,1,2,3],5,true);

    game.physics.arcade.enable(player);
    player.body.collideWorldBounds = true;
    game.physics.arcade.enable(ai);
    ai.body.collideWorldBounds = true;
    ai.body.velocity.y=-250;
    ai.body.bounce.y=1;

		    tsatoGame.createTsatos(3182);
		    tsato = game.add.group();
		    tsato.enableBody = true;
		    tsatoGame.createTsato1s(8072);
		    tsato1 = game.add.group();
		    tsato1.enableBody = true;
            pakaudio = game.add.audio('pak');


    life = game.add.text(50,10,'Life: 3',{fill:"black"});
    score = game.add.text(650,10,'Score: 0',{fill:"black"});
    bestScore = game.add.text(600,40,'High Score: '+tsatoGame.retrieveBest(),{fill:"black"});
    
    this.pauseButton = this.game.add.sprite(900,0, 'pauseButton');
        this.pauseButton.inputEnabled = true;
        this.pauseButton.events.onInputUp.add(function () {this.game.paused = true;},this);
        this.game.input.onDown.add(function () {if(this.game.paused)this.game.paused = false;},this); 
	},

	update:function (){
		game.physics.arcade.collide(player,tsato1);
		game.physics.arcade.collide(player,tsato);
		game.physics.arcade.overlap(player,line,tsatoGame.balikPosition);
    game.physics.arcade.overlap(ai2,tsato1,tsatoGame.killTsato12);

    game.physics.arcade.overlap(platform,tsato1,tsatoGame.scoreTsato1);
    game.physics.arcade.overlap(ai,tsato1,tsatoGame.killTsato1);
    game.physics.arcade.overlap(ai2,tsato,tsatoGame.killTsato2);

    game.physics.arcade.overlap(platform,tsato,tsatoGame.scoreTsato);
    game.physics.arcade.overlap(ai,tsato,tsatoGame.killTsato);

		    if(keyboard.right.isDown){
		    player1.body.velocity.x=270
		}
		else{
			ai.animations.play('ai')
		}
	}

	         
		};

		var tsatoGame = function(){
    "use strict";
    return {  
         createTsatos:function(time){
            setInterval(function(){
                 tsatos = tsato.create(580,0,"tsato");
                 tsatos.animations.add('play',[0,1,2,3,4],50, true);
                tsatos.body.velocity.y=291;
                tsatos.animations.play('play');
            },time)
        }, 
         createTsato1s:function(time){
            setInterval(function(){
                 tsato1s = tsato1.create(580,700,"tsato");
                 tsato1s.animations.add('play1',[0,1,2,3,4],50, true);
                tsato1s.body.velocity.y=-400;
                tsato1s.animations.play('play1');
            },time)
        },
        play:function(){
            buttonPlay.destroy();
        },
       
		 pushRight:function(){

			player.animations.play('player');
                player.body.velocity.x=-1750;

            
		},
		 scoreTsato:function(platform,tsatos){
                tsatos.kill();
                a = a + 1;
                score.text='Score :'+a;

                
                if(a==5){
        ai2 = game.add.sprite(200,200,'ai2');
    game.physics.arcade.enable(ai2);
    ai2.body.collideWorldBounds = true;
    ai2.body.velocity.y=283;
    ai2.body.bounce.y=1;

        ai2.animations.add('ai2',[2,0,1],9,true);
            ai2.animations.play('ai2')

    ai.body.velocity.y=200;
    ai2.body.velocity.y=250;
                }
                else if(a==10){

    ai.body.velocity.y=800;
    ai2.body.velocity.y=650;
                }
                else if(a==15){

    ai.body.velocity.y=900;
    ai2.body.velocity.y=1050;
                }
        },
         killTsato:function(ai,tsatos){
                tsatos.kill();
                b = b - 1;
                life.text='Life :'+b;
                
                
                if(b==0){
                    player.kill();
                    btnfire.destroy();
                    tsatos.destroy();

        ai.animations.stop();
    ai.body.velocity.y=0;
    ai.body.bounce.y=0;

                    goButton = game.add.button(0,0,'gameover',tsatoGame.overgame);
                    if(tsatoGame.retrieveBest() <= a){
                   localStorage.setItem("gameStorage",a);
               }
                }
            },
             killTsato2:function(ai2,tsatos){
                tsatos.kill();
                b = b - 1;
                life.text='Life :'+b;
                
                if(b==0){
                    player.kill();
                    btnfire.destroy();
                    tsatos.destroy();
                    ai.animations.stop();
    ai.body.velocity.y=0;
    ai.body.bounce.y=0;
        ai2.animations.stop();
    ai2.body.velocity.y=0;
    ai2.body.bounce.y=0;

                    goButton = game.add.button(0,0,'gameover',tsatoGame.overgame);
                    if(tsatoGame.retrieveBest() <= a){
                   localStorage.setItem("gameStorage",a);
               }
                }
        },scoreTsato1:function(platform,tsato1s){
                tsato1s.kill();
                a = a + 1;
                score.text='Score :'+a;
                pakaudio.play(); 
                
                if(a==5){
        ai2 = game.add.sprite(200,200,'ai2');
    game.physics.arcade.enable(ai2);
    ai2.body.collideWorldBounds = true;
    ai2.body.velocity.y=283;
    ai2.body.bounce.y=1;

        ai2.animations.add('ai2',[2,0,1],9,true);
            ai2.animations.play('ai2')

    ai.body.velocity.y=450;
    ai2.body.velocity.y=550;
                }
                else if(a==10){

    ai.body.velocity.y=200;
    ai2.body.velocity.y=250;
                }
                else if(a==15){

    ai.body.velocity.y=900;
    ai2.body.velocity.y=1050;
                }
        },
         killTsato1:function(ai,tsato1s){
                tsato1s.kill();
                b = b - 1;
                life.text='Life :'+b;
                
                
                if(b==0){
                    player.kill();
                    btnfire.destroy();
                    tsato1s.destroy();

        ai.animations.stop();
    ai.body.velocity.y=0;
    ai.body.bounce.y=0;

                    goButton = game.add.button(0,0,'gameover',tsatoGame.overgame);
                    if(tsatoGame.retrieveBest() <= a){
                   localStorage.setItem("gameStorage",a);
               }
                }
            },
             killTsato12:function(ai2,tsato1s){
                tsato1s.kill();
                b = b - 1;
                life.text='Life :'+b;
                
                if(b==0){
                    player.kill();
                    btnfire.destroy();
                    tsato1s.destroy();
                    ai.animations.stop();
    ai.body.velocity.y=0;
    ai.body.bounce.y=0;
        ai2.animations.stop();
    ai2.body.velocity.y=0;
    ai2.body.bounce.y=0;

                    goButton = game.add.button(0,0,'gameover',tsatoGame.overgame);
                    if(tsatoGame.retrieveBest() <= a){
                   localStorage.setItem("gameStorage",a);
               }
                }
        },
         retrieveBest:function(){
            return ((localStorage.getItem("gameStorage") != null) || (localStorage.getItem("gameStorage") != ""))?localStorage.getItem("gameStorage"):0;
        },

         overgame:function(){
            window.location.href=window.location.href;
        },
    balikPosition:function(){
        player.reset(700,300);
    }

    }
    }();


winGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}

loseGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}


