var buttonPlay, line;
var platform, player, tsato, tsatos, tsato1, tsato1s, ai, ai2;
var score, bestScore, life, line, pointer, move, retrieveBest, scoreTsato, bg, startButton, aboutButton, aboutpage, restartButton, instructionpage, instructionButton;
var a = 0, b = 3;
var goButton;
var menuText;
var playText;
var aboutText;
var keyboard;
var tsatoGame;
var bounds = 15000;
var bgmusic, loopAudio, boomusic, yaymusic;
var game = new Phaser.Game(980,600, Phaser.CANVAS, '');

game.state.add("bootGame", bootGame);
game.state.add("preloadGame", preloadGame);
game.state.add("menuGame", menuGame);
game.state.add("playGame", playGame);
game.state.add("winGame", playGame);
game.state.add("loseGame", loseGame);

game.state.start("bootGame");


